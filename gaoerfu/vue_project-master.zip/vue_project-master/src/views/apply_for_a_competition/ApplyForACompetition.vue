<template>
    <div>
        <h1>我是申请举办赛事组件，你好</h1>
    </div>
</template>

<script>
export default {
    
};
</script>

<style lang="less" scoped>

</style>