<template>
    <div>
        <h1>我是球场专区组件，你好</h1>
    </div>
</template>

<script>
export default {
    
};
</script>

<style lang="less" scoped>

</style>