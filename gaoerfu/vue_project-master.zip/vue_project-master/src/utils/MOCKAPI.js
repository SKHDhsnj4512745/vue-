const base = '/api';

// 暴露策略对象，策略模式
export default {
    [base + '/adf'](){
        return {
            a : 233333
        };
    }
};